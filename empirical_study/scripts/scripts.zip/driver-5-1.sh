#!/bin/bash
java -jar -Xmx1000M f-client.jar 1 5
