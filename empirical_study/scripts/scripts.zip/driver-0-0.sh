#!/bin/bash
java -jar f-server.jar
