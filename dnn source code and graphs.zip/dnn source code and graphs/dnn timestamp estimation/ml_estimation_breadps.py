from numpy import loadtxt
from keras.models import Sequential
from keras.layers import Dense
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from keras.optimizers import SGD
# https://hackernoon.com/build-your-first-neural-network-to-predict-house-prices-with-keras-3fb0839680f4

# Import the dataset
dataset = loadtxt('federatedparsedtimeseries2.csv', delimiter=',')

### DNN for % memory utilization time series predition
X = dataset[0:,[0,1,2,15,27,39]] # breadps
y = dataset[0:,51] 	# breadps

#Split the data for testing and training
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 42)

# Standardize the data
## Define the scaler
scaler = StandardScaler().fit(X_train)

## Scale the train set
X_train = scaler.transform(X_train)

## Scale the test set
X_test = scaler.transform(X_test)

# (0) timestamp (1) complexity (2) size_per_device (3) algorithm (4) run  
# (5) cpu1 (6) cpu2 (7) cpu3 (8) cpu4 (9) cpu5 (10) cpu6 (11) cpu7 (12) cpu8  
# (13) cpumin (14) cpumax (15) cpuavg (16) cpustd  
# (17) mem1 (18) mem2 (19) mem3 (20) mem4 (21) mem5 (22) mem6 (23) mem7 (24) mem8  
# (25) memmin (26) memmax  (27) memavg  (28) memstd  
# (29) tps1 (30) tps2  (31) tps3  (32) tps4  (33) tps5  (34) tps6  (35) tps7  (36) tps8  
# (37) tpsmin (38) tpsmax  (39) tpsavg  (40) tpsstd 
# (41) breadps1 (42) breadps2  (43) breadps3  (44) breadps4  (45) breadps5  (46) breadps6  (47) breadps7 (48) breadps8  
# (49) breadpsmin  (50) breadpsmax  (51) breadpsavg  (52) breadpsstd  
# (53) txpck1  (54) txpck2  (55) txpck3  (56) txpck4  (57) txpck5  (58) txpck6  (59) txpck7  (60) txpck8 
# (61) txpckmin  (62) txpckmax  (63) txpckavg  (63) txpckstd  
# (64) rxpck1  (65) rxpck2  (66) rxpck3  (67) rxpck4  (68) rxpck5  (69) rxpck6  (70) rxpck7  (71) rxpck8  
# (72) rxpckmin  (73) rxpckmax  (74) rxpckavg  (75) rxpckstd

model = Sequential()
model.add(Dense(12, input_dim=6, activation='relu'))
model.add(Dense(24, activation='selu'))
model.add(Dense(36, activation='relu'))
model.add(Dense(96, activation='elu'))
model.add(Dense(96, activation='selu'))
model.add(Dense(32, activation='relu'))
model.add(Dense(24, activation='selu'))
model.add(Dense(1, activation='linear'))

model.compile(loss='mean_squared_error', optimizer='adam', metrics=['accuracy'])
model.fit(X_train, y_train, epochs=200, batch_size=128, verbose=1)

from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score, cohen_kappa_score, r2_score

mse_value, mae_value = model.evaluate(X_test, y_test, verbose = 0)
print("breadps")
print("mse: ", mse_value)
print("mae: ", mae_value)

#_, accuracy = model.evaluate(X_train, y_train, verbose=0)
#print('Accuracy: %.2f' % (accuracy*100))

y_pred = model.predict(X_test)

r2 = r2_score(y_test, y_pred)

print("r2: ", r2)
